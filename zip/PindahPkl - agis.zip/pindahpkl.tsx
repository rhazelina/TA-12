<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MagangHub - Detail Pengajuan Pindah PKL</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        * { padding: 0; margin: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }

        body { background: #f8f9fa; color: #333; line-height: 1.6; }

        .main-wrapper { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }

        /* HEADER */
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px; border-bottom: 2px solid #eee; padding-bottom: 20px; }
        .brand-logo h2 { color: #641E20; font-size: 28px; font-weight: 700; }
        .brand-logo h2 span { color: #333; }
        .brand-logo p { font-size: 13px; color: #777; }

        /* CARD STYLE */
        .card { background: #fff; border-radius: 16px; padding: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); margin-bottom: 30px; border: 1px solid #eef0f2; }
        .card h3 { font-size: 18px; margin-bottom: 35px; color: #641E20; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }

        /* PROGRESS BAR */
        .status-container { display: flex; justify-content: space-between; position: relative; padding: 0 50px; }
        .status-line { position: absolute; top: 40px; left: 10%; width: 80%; height: 4px; background: #eee; z-index: 1; }
        .status-fill { position: absolute; top: 40px; left: 10%; width: 53%; height: 4px; background: #b8860b; z-index: 2; }
        .status-step { display: flex; flex-direction: column; align-items: center; z-index: 3; width: 120px; }
        .status-step span { font-size: 13px; font-weight: 600; color: #444; margin-bottom: 15px; }
        .circle { width: 20px; height: 20px; background: #b8860b; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 10px; box-shadow: 0 0 0 4px #fff; }
        .circle.inactive { background: #ccc; }

        /* FORM */
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group.full { grid-column: span 2; }
        label { font-size: 13px; font-weight: 600; margin-bottom: 10px; color: #555; }
        input, textarea { padding: 14px 18px; border: 1px solid #d1d1d1; border-radius: 12px; font-size: 14px; background: #ffffff; color: #333; transition: all 0.3s ease; }
        textarea { height: 120px; resize: vertical; }

        /* BUTTONS */
        .btn-group { display: flex; justify-content: center; gap: 25px; margin-top: 40px; }
        .btn { padding: 14px 60px; border-radius: 30px; border: none; font-weight: 600; color: white; cursor: pointer; transition: 0.3s; font-size: 14px; }
        .btn-tolak { background: #d93025; }
        .btn-tolak:hover { background: #b71c1c; }
        .btn-izinkan { background: #0f9d58; }
        .btn-izinkan:hover { background: #0b8043; }

        /* MODAL */
        .modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); display: none; justify-content: center; align-items: center; z-index: 9999; }
        .modal-card { background: white; width: 400px; border-radius: 25px; padding: 35px; text-align: center; }
        .modal-card i { font-size: 50px; color: #4CAF50; margin-bottom: 15px; }
    </style>
</head>
<body>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="brand-logo">
                <h2>Magang<span>Hub</span></h2>
                <p>Sistem Informasi Manajemen PKL</p>
            </div>
        </header>

        <section class="card">
            <h3>Status Persetujuan</h3>
            <div class="status-container">
                <div class="status-line"></div>
                <div class="status-fill"></div>
                
                <div class="status-step">
                    <span>Pembimbing</span>
                    <div class="circle"><i class="fas fa-check"></i></div>
                </div>
                
                <div class="status-step">
                    <span>Kapro</span>
                    <div class="circle"><i class="fas fa-check"></i></div>
                </div>
                
                <div class="status-step">
                    <span>Koordinator</span>
                    <div class="circle inactive"></div>
                </div>
                
                <div class="status-step">
                    <button class="btn" style="padding: 5px 15px; background:#eee; color:#aaa; font-size:10px; cursor:default;">SELESAI</button>
                </div>
            </div>
        </section>

        <section class="card">
            <h3>Detail Pengajuan Pindah PKL</h3>
            <form id="editForm" onsubmit="handleSave(event)">
                <div class="form-grid">

                    <div class="form-group full">
                        <label>Nama Lengkap</label>
                        <input type="text" value="Iqbal Lazuardi">
                    </div>

                    <div class="form-group">
                        <label>Jurusan</label>
                        <input type="text" value="Rekayasa Perangkat Lunak">
                    </div>

                    <div class="form-group">
                        <label>Kelas</label>
                        <input type="text" value="XI RPL 1">
                    </div>

                    <div class="form-group">
                        <label>Tempat Magang Saat Ini</label>
                        <input type="text" value="UBIG">
                    </div>

                    <div class="form-group">
                        <label>Tempat Magang Tujuan</label>
                        <input type="text" value="PT. Peternakan Kambing">
                    </div>

                    <div class="form-group full">
                        <label>Alasan Perpindahan</label>
                        <textarea>Mental rusak karena pembimbing yang terlalu menekan serta tugas di luar keahlian.</textarea>
                    </div>

                </div>

                <div class="btn-group">
                    <button type="button" class="btn btn-tolak" onclick="handleTolak()">Tolak</button>
                    <button type="submit" class="btn btn-izinkan">Izinkan</button>
                </div>
            </form>
        </section>
    </div>

    <!-- MODAL SUKSES -->
    <div class="modal-overlay" id="successModal">
        <div class="modal-card">
            <i class="fas fa-check-circle"></i>
            <h3>Berhasil!</h3>
            <p style="margin-top: 10px; color: #666;">Aksi berhasil diproses.</p>
            <button class="btn btn-izinkan" style="margin-top: 25px; padding: 10px 40px;" onclick="hideModal()">Oke</button>
        </div>
    </div>

    <!-- MODAL KONFIRMASI TOLAK -->
    <div class="modal-overlay" id="confirmModal">
        <div class="modal-card">
            <img src="https://via.placeholder.com/120" style="margin-bottom: 15px;">
            <h3 style="margin-bottom: 10px;">Apakah anda yakin ingin <b style='color:#d93025'>menolak</b> pengajuan pindah PKL ini?</h3>

            <div style="display:flex; justify-content:center; gap:20px; margin-top:25px;">
                <button class="btn btn-izinkan" style="padding: 10px 35px;" onclick="hideConfirm()">Tidak</button>
                <button class="btn btn-tolak" style="padding: 10px 35px;" onclick="confirmTolak()">Iya</button>
            </div>
        </div>
    </div>

    <script>
        function handleSave(event) {
            event.preventDefault();
            document.getElementById('successModal').style.display = 'flex';
        }
        function handleTolak() {
            document.getElementById('confirmModal').style.display = 'flex';
        }
        function hideConfirm() {
            document.getElementById('confirmModal').style.display = 'none';
        }
        function confirmTolak() {
            document.getElementById('confirmModal').style.display = 'none';
            document.getElementById('successModal').style.display = 'flex';
        }
        function hideModal() {
            document.getElementById('successModal').style.display = 'none';
        }
    </script>

</body>
</html>